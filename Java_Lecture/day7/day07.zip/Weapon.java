package day07;

public interface Weapon {
	public void use();
	void reuse();
}
