package day07;

public class TestMain4 {
	public static void main(String[] args) {
		
//		Parent p = new Parent();
//		Child c = new Child();
//		p = c; 
		
		Parent p = new Child();
		
		
		
		
		
	}
}
