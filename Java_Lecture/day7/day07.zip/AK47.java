package day07;

public class AK47  implements  Weapon{

	@Override
	public void use() {
		System.out.println("AK47 : �ѶѶ�");
		
	}

	@Override
	public void reuse() {
		System.out.println("AK47 : reload...");
		
	}

}
