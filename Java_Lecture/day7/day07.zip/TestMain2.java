package day07;

import day06.Horse;
import day06.Marine;
import day06.Medic;
import java.util.Scanner;


public class TestMain2 {
	public static void main(String[] args) {
		Child c = new Child();
		c.singing();
		c.nagging();
		c.eating();
		c.goClub();
		System.out.println("--------------------");
		Parent p = new Parent();
		p.eating();
		p.nagging();
		p.singing();
		//p.goClub();
		Child c2 ; 
		// c2 = 100;
		// �䳢 
		day06.Rabbit r  = new day06.Rabbit();
		day06.Rabbit r2  = new day06.Rabbit();
		System.out.println(" r : " + r);
		System.out.println(" r2 : " + r2);
		r = r2; 
		System.out.println(" r : " + r);
		System.out.println(" r2 : " + r2);
		
		// c = r;
		// ���� �ٸ� Ŭ���������� ���� ���� �ټ� ����. 
		
//		Marine m ; 
//		Medic me;
//		Horse h;
		// ctl + shift + o : �ڵ� import 
		
		
	}
}
