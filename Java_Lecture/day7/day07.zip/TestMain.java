package day07;

public class TestMain {
	public static void main(String[] args) {
		ATM atm = new ATM("ȫ�浿", 10000);
		//ATM atm2 = new ATM(); 
		atm.deposit(5000);
		//atm.balance=999999999;
		
		atm.withDraw(3000000);
		
	}
}
