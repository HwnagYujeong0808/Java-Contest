package day07;

public class TestMain5 {
	public static void main(String[] args) {
		// ��� 
		
		
	}
}
