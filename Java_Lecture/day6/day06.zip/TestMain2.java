package day06;

public class TestMain2 {
	public static void main(String[] args) {
		SuperMan sm = new SuperMan();
		System.out.println(sm.name);
		
	}
}
